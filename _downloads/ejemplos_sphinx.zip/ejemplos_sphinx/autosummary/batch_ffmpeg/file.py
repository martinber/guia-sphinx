"""
Herramientas para el manejo de archivos.

TODO:
    * Forma de obtener paths individualmente, por ahora solamente se pueden
      obtener todos los paths de archivo desde una carpeta
"""

import os
import errno

def _replace_extension(path, extension):
    """
    Reemplazar extensión del path dado.

    No cambia la extensión del archivo, solamente modifica el string que
    representa al path. Elimina todo lo que haya después del último ``.`` y
    coloca la nueva extensión.

    Args:
        path (str): String que representa a un path.
        extension (str): Extensión a colocar, no se debe proporcionar el ``.``,
            ej: ``mp3``.

    Returns:
        str: Nuevo path
    """

    name, _ = os.path.splitext(path)
    return name + '.' + extension

def get_paths_from_folder(in_folder, in_extension, out_folder, out_extension):
    """
    Obtener paths de entrada y salida para todos los archivos presentes en la
    carpeta de entrada con la extensión de entrada.

    Devuelve una lista con los paths de entrada y otra con los paths de salida.

    Args:
        in_folder (str): Path a la carpeta de entrada, debe existir.
        in_extension (str): Extensión de los archivos de entrada, no incluir el
            ``.``, ej: ``mp3``.
        out_folder (str): Path a la carpeta de salida, puede no existir.
        out_extension (str): Extensión de los archivos de salida, no incluir el
            ``.``, ej: ``mp3``.

    Returns:
        Un tuple con dos listas, una con los paths de entrada y otra con los
        paths de salida.

        La lista de paths de entrada se corresponde a todos los archivos
        encontrados en la carpeta de entrada con la extensión de entrada dada.

        La lista de paths de salida se corresponde a los mismos archivos que
        están en la lista de entrada pero ubicados la carpeta de salida con la
        extensión de salida.

    Raises:
        FileNotFoundError: Si la carpeta de entrada no existe.

    Examples:
        Un ejemplo de uso sería::

            get_paths_from_folder('./videos', 'avi', './convertidos', 'webm')

        Y un ejemplo de lo que se devuelve es::

            (
                ['./videos/vid1.avi', './videos/vid1.avi', './videos/vid1.avi'],

                ['./convertidos/vid1.webm', './convertidos/vid1.webm',
                './convertidos/vid1.webm']
            )
    """

    if not folder_exists(in_folder):
        raise FileNotFoundError(errno.ENOENT, os.strerror(errno.ENOENT),
                in_folder)

    # nombres de archivos
    in_names = os.listdir(in_folder)

    # agregar carpeta de entrada a los nombres de archivos
    in_paths = [os.path.join(in_folder, n) for n in in_names
            if n.endswith("." + in_extension)]

    # cambiar extensión
    out_paths = [_replace_extension(p, out_extension) for p in in_paths]

    # cambiar carpeta contenedora para los archivos de salida
    out_paths = [os.path.join(out_folder, os.path.basename(p))
                    for p in out_paths]

    return in_paths, out_paths

def folder_exists(path):
    """
    Indica si la carpeta dada existe.

    Args:
        path (str): Path a la carpeta.

    Returns:
        bool: ``True`` si la carpeta existe y ``False`` de lo contrario.
    """

    return os.path.isdir(path)
