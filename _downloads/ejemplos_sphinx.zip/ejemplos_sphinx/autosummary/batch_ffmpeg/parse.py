"""
Código necesario para parsear la salida de *FFMPEG*.
"""

import re

class ffmpeg_parser:
    """
    Recibe stderr de *FFMPEG*, línea por línea y obtiene información sobre el
    archivo actual.
    """

    def __init__(self):

        self.file = None
        """
        str: Nombre de archivo de entrada actual.

        Es None si todavía no es conocido.
        """

        self.duration = None
        """
        float: Duración del archivo actual, en segundos.

        Es None si todavía no es conocido.
        """

        self.time = None
        """
        float: Tiempo actual en la conversión del archivo actual, en segundos.

        Es None si todavía no es conocido.
        """


    def update(self, line: str):
        """
        Actualizarse a partir de una línea.

        Args:
            line (str): Línea de stdout a parsear.
        """

        # línea que contiene al nombre de archivo

        # ejemplo:
        # Input #0, ogg, from '/home/usuario/cancion ' con comilla.ogg':
        if "Input #0, " in line:
            _, line = line.split("'", maxsplit=1)
            line, _ = line.rsplit("'", maxsplit=1)
            self.file = line
            self.time = None # porque se supone que cambiamos de archivo

        # línea que contiene a la duración

        # ejemplo:
        # Duration: 00:08:58.12, start: 0.000000, bitrate: 138 kb/s
        if re.search(r"Duration:.*, start:.*, bitrate:.*", line):
            string = re.search(r"[0-9]+:[0-9]+:[0-9]+.[0-9]+", line).group()
            h, m, s = string.split(":")
            self.duration = float(s) + int(m) * 60 + int(h) * 3600
            self.time = None # porque se supone que cambiamos de archivo

        # línea que contiene al tiempo actual

        # ejemplo:
        # size=     953kB time=00:01:21.26 bitrate=  96.1kbits/s speed=23.2x

        if is_progress(line):
            string = re.search(r"[0-9]+:[0-9]+:[0-9]+.[0-9]+", line).group()
            h, m, s = string.split(":")
            self.time = float(s) + int(m) * 60 + int(h) * 3600

    def get_current_file_progress(self):
        """
        Obtener progreso de la conversión en el archivo actual.

        Returns:
            float: Un número entre 0 y 1.

            Puede ser None si no se conoce el progreso actual
        """

        if self.duration and self.time:
            return self.time / self.duration
        else:
            return None

def is_progress(line):
    """
    Devuelve True si la línea dada se corresponde a la información sobre el
    progreso actual de *FFMPEG*.

    Las líneas que no cumplen son por lo tanto información que puede ser
    importante para el usuario.

    Las líneas que tienen información del progreso actual se ven así::

      size=     953kB time=00:01:21.26 bitrate=  96.1kbits/s speed=23.2x

    Returns:
        bool: True si la línea se corresponde a la información sobre el progreso
        actual de *FFMPEG*.
    """

    if re.search(r"size=.*time=.*bitrate=.*speed=.*", line):
        return True
    else:
        return False
