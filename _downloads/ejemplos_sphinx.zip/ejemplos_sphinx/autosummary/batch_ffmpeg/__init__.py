"""
``batch_ffmpeg`` es una herramienta para convertir de forma masiva archivos
utilizando *FFMPEG*.

En el paquete :py:mod:`ui` están las interfaces de usuario.

Ver documentación de :py:mod:`ui.shell` para el uso en la terminal.
"""

from .convert import *
from . import file
