"""
Contiene la interfaz de usuario para línea de comandos.
"""

import argparse

import batch_ffmpeg

def main():
    """
    Punto de entrada del programa para la línea de comandos.

    Lee los argumentos de entrada y realiza las conversiones solicitadas.

    Permite realizar una conversión por carpetas o por archivos::

      batch_ffmpeg [-h] [-q] [-Q] {folder,files} ...

    Argumentos opcionales::

      -h, --help         Ayuda
      -q, --quiet        No mostrar la salida de FFMPEG
      -Q, --no-progress  No mostrar el progreso

    .. rubric:: Uso de modo "folder":

    ::

      batch_ffmpeg folder [-h]
                          in_folder in_extension out_folder out_extension ...

    Argumentos posicionales::

      in_folder      Carpeta en la cual buscar los archivos a convertir
      in_extension   Extensión de los archivos que se quieren convertir
      out_folder     Carpeta en donde guardar los archivos convertidos
      out_extension  Extensión a colocar a los archivos convertidos
      ffmpeg_args    Argumentos para FFMPEG

    .. rubric:: Uso de modo "files":
    ::

      batch_ffmpeg files [-h] [-e OUT_EXTENSION] [-i IN_FILES [IN_FILES ...]]
                          [-o OUTPUT_FOLDER]
                          ...

    Argumentos posicionales::

      ffmpeg_args           Argumentos para FFMPEG

    Argumentos opcionales::

      -h, --help            show this help message and exit
      -e OUT_EXTENSION, --out-extension OUT_EXTENSION
                            Extensión de salida
      -i IN_FILES [IN_FILES ...], --in-files IN_FILES [IN_FILES ...]
                            Archivos a convertir
      -o OUTPUT_FOLDER, --output-folder OUTPUT_FOLDER
                            Carpeta en donde guardar los archivos convertidos
    """

    args = _parse_args()

    def print_progress(progress):
        if progress.current_progress is not None:
            print(progress)

    if args.quiet:
        output_callback = None
    else:
        output_callback = print

    if args.no_progress:
        progress_callback = None
    else:
        progress_callback = print_progress

    if args.subparser == "folder":

        batch_ffmpeg.convert_folder(args.in_folder, args.in_extension,
                args.out_folder, args.out_extension, args.ffmpeg_args,
                output_callback=output_callback, progress_callback=progress_callback)

    elif args.subparser == "files":

        # TODO
        raise NotImplementedError('La opción "files" todavía no está implementada"')

        #  batch_ffmpeg.convert_files(in_paths, out_paths, args.ffmpeg_args,
                #  output_callback=output_callback,
                #  progress_callback=progress_callback)



def _parse_args():
    """
    Parsear los argumentos.

    Returns:
        argparse.Namespace: Objeto que contiene los argumentos dados al
        programa.
    """

    parser = argparse.ArgumentParser(prog="batch_ffmpeg",
            description="Herramienta para convertir varios archivos fácilmente "
            "con ffmpeg")


    parser.add_argument("-q", "--quiet", action="store_true",
            help="No mostrar la salida de FFMPEG")

    parser.add_argument("-Q", "--no-progress", action="store_true",
            help="No mostrar el progreso")

    subparsers = parser.add_subparsers(dest="subparser")
    subparsers.required = True

    parser_folder = subparsers.add_parser("folder",
            help="Convertir todos los archivos de una carpeta con la extensión "
            "dada")

    parser_folder.add_argument("in_folder",
            help="Carpeta en la cual buscar los archivos a convertir")

    parser_folder.add_argument("in_extension",
            help="Extensión de los archivos que se quieren convertir")

    parser_folder.add_argument("out_folder",
            help="Carpeta en donde guardar los archivos convertidos")

    parser_folder.add_argument("out_extension",
            help="Extensión a colocar a los archivos convertidos")

    parser_folder.add_argument("ffmpeg_args", nargs=argparse.REMAINDER,
            help="Argumentos para FFMPEG")


    parser_files = subparsers.add_parser("files",
            help="Convertir los archivos dados")

    parser_files.add_argument("ffmpeg_args", nargs=argparse.REMAINDER,
            help="Argumentos para FFMPEG")

    parser_files.add_argument("-e", "--out-extension", nargs=1,
            help="Extensión de salida")

    parser_files.add_argument("-i", "--in-files", nargs="+",
            help="Archivos a convertir")

    parser_files.add_argument("-o", "--output-folder", nargs=1,
            help="Carpeta en donde guardar los archivos convertidos")

    return parser.parse_args()
