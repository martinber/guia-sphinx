"""
Interfaz interactiva para la línea de comandos.

Todo:

  * No hice nada todavia.

"""
