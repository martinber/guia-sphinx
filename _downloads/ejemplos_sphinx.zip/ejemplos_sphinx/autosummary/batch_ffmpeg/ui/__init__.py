"""
Interfaces de usuario.
"""
