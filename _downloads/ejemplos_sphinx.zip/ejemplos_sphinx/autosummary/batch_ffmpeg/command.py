"""
Herramientas para la ejecución de comandos de shell.
"""

import subprocess
import threading

def execute(args, stdout_callback=None, stderr_callback=None):
    """
    Ejecuta un comando.

    Esta función bloquea hasta que el proceso iniciado finalice. Hay callbacks
    para stdout y stderr.

    Los callbacks envían como argumento una línea del stream, ya sea stdout o
    stderr. Los callbacks son llamados apenas hay una nueva línea disponible
    utilizando *threading*.

    Args:
        args (List[str]): Lista con el nombre de programa a ejecutar y sus
            argumentos. Ej: ``['sudo', 'apt-get', 'install', 'python3']``
        stdout_callback (Callable[[str], None]): Función callback para stdout.
        stderr_callback (Callable[[str], None]): Función callback para stderr.
    """

    p = subprocess.Popen(args, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, universal_newlines=True)

    def watch(p, stream):
        """
        Lee un stream perteneciente a un proceso p.

        Args:
            p (subprocess.Popen): Proceso a controlar.
            stream (str): Nombre del stream a controlar, puede ser "stdout" o
                "stderr".
        """

        if stream == "stdout" and stdout_callback:
            while p.poll() is None:
                stdout_callback(p.stdout.readline().rstrip("\n"))
        if stream == "stderr" and stderr_callback:
            while p.poll() is None:
                stderr_callback(p.stderr.readline().rstrip("\n"))

    t1 = threading.Thread(target=watch, args=(p, "stdout"))
    t2 = threading.Thread(target=watch, args=(p, "stderr"))

    t1.start()
    t2.start()
    t1.join()
    t2.join()

    p.wait()
