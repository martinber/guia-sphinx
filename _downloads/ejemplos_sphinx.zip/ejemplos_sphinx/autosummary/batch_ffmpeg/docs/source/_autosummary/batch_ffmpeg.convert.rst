batch_ffmpeg.convert
====================

.. currentmodule:: batch_ffmpeg.convert



.. rubric:: Functions

.. autosummary::

  convert_files
  convert_folder





.. rubric:: Classes

.. autosummary::

  Progress







.. automodule:: batch_ffmpeg.convert
   :members:
   :private-members: