batch_ffmpeg.ui.shell
=====================

.. currentmodule:: batch_ffmpeg.ui.shell



.. rubric:: Functions

.. autosummary::

  main











.. automodule:: batch_ffmpeg.ui.shell
   :members:
   :private-members: