batch_ffmpeg.file
=================

.. currentmodule:: batch_ffmpeg.file



.. rubric:: Functions

.. autosummary::

  folder_exists
  get_paths_from_folder











.. automodule:: batch_ffmpeg.file
   :members:
   :private-members: