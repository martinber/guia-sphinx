batch_ffmpeg.command
====================

.. currentmodule:: batch_ffmpeg.command



.. rubric:: Functions

.. autosummary::

  execute











.. automodule:: batch_ffmpeg.command
   :members:
   :private-members: