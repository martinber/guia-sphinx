"""
Código referido a la conversión de los archivos.
"""

import os

from . import parse
from . import command
from . import file

def convert_files(in_paths, out_paths, ffmpeg_arguments, output_callback=None,
        progress_callback=None):
    """
    Convertir una lista de archivos con *FFMPEG*.

    Convierte los archivos de entrada y los guarda con los nombres dados en la
    lista de salida.

    Realiza callbacks con el progreso actual o con la salida de *FFMPEG* si así
    se lo indica.

    Args:
        in_paths (str): Lista de paths archivos de entrada, deben existir.
        out_paths (str): Lista de paths archivos de salida, no deben existir.
        ffmpeg_arguments (List[str]): Argumentos para *FFMPEG*. Ej: ``["c:v",
            "vp9", "c:a", "mp3"]```.
        output_callback (Callable[[str], None]): Función callback para la salida
            de *FFMPEG*, es llamada cada vez que *FFMPEG* imprime una línea que
            no sea sobre el progreso.
        progress_callback (Callable[Progress], None]): Función callback para
            el progreso de la conversión. Da como argumento una instancia de
            *Progress*.
    """

    total_files = len(in_paths)

    # crear un parser para la salida de FFMPEG
    parser = parse.ffmpeg_parser()

    def callback_handle(parser, total_files, current_file, line):
        """
        Se encarga de recibir el callback del comando y llama al
        progress_callback si fue solicitado.

        Recibe en tiempo real la salida de *FFMPEG*, el parser, la cantidad
        total de archivos y el número de archivo actual. Con eso obtiene el
        progreso actual y lo envía al progress_callback.
        """
        parser.update(line)

        current_progress = parser.get_current_file_progress()
        current_file_name = parser.file
        progress = Progress(current_file, total_files, current_progress,
                current_file_name)

        if progress_callback and parse.is_progress(line):
            progress_callback(progress)
        elif output_callback and not parse.is_progress(line):
            output_callback(line)

    for i in range(total_files):
        args = ['ffmpeg', '-i', in_paths[i], *ffmpeg_arguments, out_paths[i]]

        if progress_callback or output_callback:
            command.execute(args, None,
                    lambda line, total_files=total_files, current_file=i+1,
                    parser=parser:
                        callback_handle(parser, total_files, current_file, line))
        else:
            command.execute(args, None, None)

def convert_folder(in_folder, in_extension, out_folder, out_extension,
        ffmpeg_arguments, output_callback=None, progress_callback=None):
    """
    Convertir archivos de una carpeta con *FFMPEG*.

    Convierte todos los archivos presentes en la carpeta de entrada que tengan
    la extensión de entrada dada. La conversión se realiza con *FFMPEG* y se
    usan los argumentos dados. Los archivos de salida se guardan en la carpeta
    dada, con la extensión de salida dada y con el mismo nombre de archivo que
    el origen.

    Realiza callbacks con el progreso actual o con la salida de *FFMPEG* si así
    se lo indica.

    Args:
        in_folder (str): Path a la carpeta de entrada, debe existir.
        in_extension (str): Extensión de los archivos de entrada, no incluir el
            ``.``, ej: ``mp3``.
        out_folder (str): Path a la carpeta de salida, puede no existir.
        out_extension (str): Extensión de los archivos de salida, no incluir el
            ``.``, ej: ``mp3``.
        ffmpeg_arguments (List[str]): Argumentos para *FFMPEG*. Ej: ``["c:v",
            "vp9", "c:a", "mp3"]```.
        output_callback (Callable[[str], None]): Función callback para la salida
            de *FFMPEG*, es llamada cada vez que *FFMPEG* imprime una línea que
            no sea sobre el progreso.
        progress_callback (Callable[Progress], None]): Función callback para
            el progreso de la conversión. Da como argumento una instancia de
            *Progress*.
    """

    if not file.folder_exists(out_folder):
        os.mkdir(out_folder)

    in_paths, out_paths = file.get_paths_from_folder(in_folder, in_extension,
            out_folder, out_extension)

    convert_files(in_paths, out_paths, ffmpeg_arguments, output_callback,
            progress_callback)

class Progress:
    """
    Representa al progreso de la conversión.

    Lleva la cuenta de la cantidad de archivos convertidos, la cantidad total de
    archivos a convertir, el progreso en la conversión actual, y el nombre de
    archivo actual.

    Args:
        current_file (int): Número de archivo que se está convirtiendo
            actualmente. Debe ser un número mayor o igual a 1.
        total_files (int): Número total de archivos a convertir. Debe ser mayor
            o igual a 1.
        current_progress (float): Número entre 0 y 1 que representa al progreso
            de la conversión en el archivo actual.
    """

    def __init__(self, current_file, total_files, current_progress,
            current_file_name):

        self.current_file = current_file
        """
        int: Número que representa al archivo actual que se está convirtiendo.
        """

        self.total_files = total_files
        """
        int: Cantidad de archivos que se están convirtiendo.
        """

        self.current_progress = current_progress
        """
        int: Número entre 0 y 1 que representa al progreso en la conversión del
        archivo actual
        """

        self.current_file_name = current_file_name

    def get_global_progress(self):
        """
        Obtener progreso global de la conversión.

        Muestra el progreso relativo a la cantidad de archivos convertidos
        versus la cantidad total de archivos. No tiene en cuenta al progreso en
        la conversión actual.

        Returns:
            float: Un número entre 0 y 1.
        """

        return (self.current_file - 1) / self.total_files

    def get_current_file_progress(self):
        """
        Obtener progreso de la conversión en el archivo actual.

        Returns:
            float: Un número entre 0 y 1.
        """

        return self.current_progress

    def __str__(self):
        if self.current_progress:
            current_progress = self.current_progress * 100
        else:
            current_progress = "-"
        return "File {} of {}: {:.4}%".format(self.current_file,
                self.total_files, current_progress)
