pynprcalc.funciones.math.basico
===============================

.. currentmodule:: pynprcalc.funciones.math.basico



.. rubric:: Functions

.. autosummary::

  cuadrado
  division
  inverso
  opuesto
  potencia
  producto
  raiz
  raiz_cuadrada
  resta
  suma











.. automodule:: pynprcalc.funciones.math.basico
   :members:
   :private-members: