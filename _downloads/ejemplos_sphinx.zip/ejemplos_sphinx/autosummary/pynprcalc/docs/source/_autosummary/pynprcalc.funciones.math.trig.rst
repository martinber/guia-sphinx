pynprcalc.funciones.math.trig
=============================

.. currentmodule:: pynprcalc.funciones.math.trig



.. rubric:: Functions

.. autosummary::

  acos
  asen
  atg
  cos
  sen
  tg











.. automodule:: pynprcalc.funciones.math.trig
   :members:
   :private-members: