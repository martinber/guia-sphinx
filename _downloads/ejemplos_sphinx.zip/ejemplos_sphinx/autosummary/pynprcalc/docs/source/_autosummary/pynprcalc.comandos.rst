pynprcalc.comandos
==================

.. currentmodule:: pynprcalc.comandos



.. rubric:: Functions

.. autosummary::

  obtener_funcion











.. automodule:: pynprcalc.comandos
   :members:
   :private-members: