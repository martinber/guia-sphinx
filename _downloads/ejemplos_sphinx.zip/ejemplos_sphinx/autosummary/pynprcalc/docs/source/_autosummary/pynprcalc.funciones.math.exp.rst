pynprcalc.funciones.math.exp
============================

.. currentmodule:: pynprcalc.funciones.math.exp



.. rubric:: Functions

.. autosummary::

  exp
  ln
  log
  log10











.. automodule:: pynprcalc.funciones.math.exp
   :members:
   :private-members: