pynprcalc.funciones.math.const
==============================

.. currentmodule:: pynprcalc.funciones.math.const



.. rubric:: Functions

.. autosummary::

  e
  pi











.. automodule:: pynprcalc.funciones.math.const
   :members:
   :private-members: