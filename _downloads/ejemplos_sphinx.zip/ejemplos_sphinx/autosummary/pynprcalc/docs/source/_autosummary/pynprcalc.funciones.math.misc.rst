pynprcalc.funciones.math.misc
=============================

.. currentmodule:: pynprcalc.funciones.math.misc



.. rubric:: Functions

.. autosummary::

  grados_a_radianes
  radianes_a_grados











.. automodule:: pynprcalc.funciones.math.misc
   :members:
   :private-members: