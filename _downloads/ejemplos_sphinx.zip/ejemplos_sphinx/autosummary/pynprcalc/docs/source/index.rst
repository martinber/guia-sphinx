.. pynprcalc documentation master file, created by
   sphinx-quickstart on Sat Jun 17 20:20:31 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentacion de pynprcalc
==========================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Esta es una calculadora RPN.

.. autosummary::
   :toctree: _autosummary

   pynprcalc.calc.main
   pynprcalc.calc.ui
   pynprcalc.funciones.misc
   pynprcalc.funciones.math.basico
   pynprcalc.funciones.math.const
   pynprcalc.funciones.math.exp
   pynprcalc.funciones.math.trig
   pynprcalc.funciones.math.misc
   pynprcalc.comandos

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
