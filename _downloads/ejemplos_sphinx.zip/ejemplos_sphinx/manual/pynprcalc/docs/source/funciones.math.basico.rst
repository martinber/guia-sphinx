funciones.math.basico
=====================

.. automodule:: pynprcalc.funciones.math.basico
   :members:
