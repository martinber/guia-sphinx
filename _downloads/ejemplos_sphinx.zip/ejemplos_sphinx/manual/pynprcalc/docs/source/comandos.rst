comandos
========

.. automodule:: pynprcalc.comandos
   :members:
