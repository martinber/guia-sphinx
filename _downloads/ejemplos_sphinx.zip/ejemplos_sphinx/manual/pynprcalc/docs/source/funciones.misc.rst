funciones.misc
==============

.. automodule:: pynprcalc.funciones.misc
   :members:
