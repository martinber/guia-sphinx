funciones
=========

.. Este "automodule" incluye la documentacion del __init__ del paquete

.. automodule:: pynprcalc.funciones

.. toctree::

    funciones.math
    funciones.misc
