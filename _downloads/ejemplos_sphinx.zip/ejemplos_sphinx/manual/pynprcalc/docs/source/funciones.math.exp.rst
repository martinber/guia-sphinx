funciones.math.exp
==================

.. automodule:: pynprcalc.funciones.math.exp
   :members:
