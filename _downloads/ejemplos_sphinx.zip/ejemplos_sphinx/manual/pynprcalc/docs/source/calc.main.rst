calc.main
=========

.. automodule:: pynprcalc.calc.main
   :members:
