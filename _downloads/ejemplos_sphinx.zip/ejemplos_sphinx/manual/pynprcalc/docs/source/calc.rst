calc
====

.. Este "automodule" incluye la documentacion del __init__ del paquete

.. automodule:: pynprcalc.calc

.. toctree::

    calc.main
    calc.ui
