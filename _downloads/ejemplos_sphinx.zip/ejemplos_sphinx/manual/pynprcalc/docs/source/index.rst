.. pynprcalc documentation master file, created by
   sphinx-quickstart on Sun Jun 18 09:56:12 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentación de pynprcalc
==========================

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   calc
   funciones
   comandos

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
