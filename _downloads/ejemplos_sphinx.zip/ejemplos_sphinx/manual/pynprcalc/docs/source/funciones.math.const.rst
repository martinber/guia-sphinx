funciones.math.const
=====================

.. automodule:: pynprcalc.funciones.math.const
   :members:
