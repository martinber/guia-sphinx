funciones.math
==============

.. Este "automodule" incluye la documentacion del __init__ del paquete

.. automodule:: pynprcalc.funciones.math

.. toctree::

    funciones.math.basico
    funciones.math.const
    funciones.math.exp
    funciones.math.trig
    funciones.math.misc
