funciones.math.trig
===================

.. automodule:: pynprcalc.funciones.math.trig
   :members:
