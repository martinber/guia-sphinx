funciones.math.misc
===================

.. automodule:: pynprcalc.funciones.math.misc
   :members:
