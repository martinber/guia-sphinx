parse
=====

.. automodule:: batch_ffmpeg.parse
    :members:
