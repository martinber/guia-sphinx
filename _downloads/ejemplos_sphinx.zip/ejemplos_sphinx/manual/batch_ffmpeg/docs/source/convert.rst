convert
=======

.. automodule:: batch_ffmpeg.convert
    :members:
