ui
==

.. Este "automodule" incluye la documentacion de ui.__init__

.. automodule:: batch_ffmpeg.ui

.. toctree::

    ui.shell
    ui.interactive
