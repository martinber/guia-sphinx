file
====

.. automodule:: batch_ffmpeg.file
    :members:
