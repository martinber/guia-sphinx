ui.interactive
==============

.. automodule:: batch_ffmpeg.ui.interactive
    :members:
