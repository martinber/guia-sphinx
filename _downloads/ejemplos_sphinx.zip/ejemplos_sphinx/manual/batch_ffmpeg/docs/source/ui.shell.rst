ui.shell
========

.. automodule:: batch_ffmpeg.ui.shell
    :members:
