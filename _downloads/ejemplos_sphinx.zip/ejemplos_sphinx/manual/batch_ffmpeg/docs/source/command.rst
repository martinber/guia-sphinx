command
=======

.. automodule:: batch_ffmpeg.command
    :members:
