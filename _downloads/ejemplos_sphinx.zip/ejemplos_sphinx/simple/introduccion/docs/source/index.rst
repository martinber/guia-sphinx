Documentación de introducción
=============================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Acá puedo poner una descripción...

.. automodule:: introduccion
    :members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
