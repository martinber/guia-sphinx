.. Magia documentation master file, created by
   sphinx-quickstart on Sat Jun 17 19:45:57 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentación de Magia
======================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

Este es un programa que hace un truco de magia!

cartas.py
---------

.. automodule:: cartas
    :members:
    :private-members:

magia.py
---------

.. automodule:: magia
    :members:
    :private-members:

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
